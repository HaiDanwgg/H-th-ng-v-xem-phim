const path = require('path');
const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const helmet = require('helmet');
const client = require('prom-client');
const winston = require('winston');

const {
  PORT = 3000, DB_HOST = 'db', DB_NAME = 'cinema', DB_USER, DB_PASSWORD,
  JWT_SECRET = 'doi-secret-nay', ADMIN_PASSWORD = 'Admin@123', DEMO_PASSWORD = 'User@123',
} = process.env;

// ---------- Log JSON ra stdout (Promtail -> Loki) ----------
const log = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message, ...meta }) =>
      JSON.stringify({ ts: timestamp, level, msg: message, ...meta }))
  ),
  transports: [new winston.transports.Console()],
});

// ---------- Prometheus metrics ----------
client.collectDefaultMetrics();
const httpDuration = new client.Histogram({
  name: 'http_request_duration_seconds',
  help: 'Thoi gian xu ly request',
  labelNames: ['method', 'route', 'status'],
  buckets: [0.05, 0.1, 0.3, 0.5, 1, 2],
});
const bookingsTotal = new client.Counter({
  name: 'bookings_total', help: 'So don dat ve theo trang thai', labelNames: ['status'],
});

const pool = mysql.createPool({
  host: DB_HOST, user: DB_USER, password: DB_PASSWORD, database: DB_NAME,
  waitForConnections: true, connectionLimit: 10, timezone: 'Z',
});

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', true);
app.use(helmet({ contentSecurityPolicy: false })); // CSP do Nginx dat
app.use(express.json({ limit: '10kb' }));

app.use((req, res, next) => {
  const end = httpDuration.startTimer();
  res.on('finish', () => {
    const route = req.route ? (req.baseUrl || '') + req.route.path : 'static_or_404';
    end({ method: req.method, route, status: res.statusCode });
  });
  next();
});

const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
const fail = (res, code, error) => res.status(code).json({ error });

function auth(req, res, next) {
  const h = req.headers.authorization || '';
  try {
    req.user = jwt.verify(h.startsWith('Bearer ') ? h.slice(7) : '', JWT_SECRET);
    next();
  } catch (e) { fail(res, 401, 'UNAUTHORIZED'); }
}
const adminOnly = (req, res, next) =>
  req.user.role === 'admin' ? next() : fail(res, 403, 'FORBIDDEN');
const sign = (u) => jwt.sign({ id: u.id, email: u.email, role: u.role }, JWT_SECRET, { expiresIn: '2h' });

// ---------- Health & metrics ----------
app.get('/health', (req, res) => res.json({ status: 'ok' }));
app.get('/metrics', wrap(async (req, res) => {
  res.set('Content-Type', client.register.contentType);
  res.end(await client.register.metrics());
}));

// ---------- Auth ----------
app.post('/api/auth/register', wrap(async (req, res) => {
  const { email, password } = req.body || {};
  if (typeof email !== 'string' || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || email.length > 120)
    return fail(res, 400, 'INVALID_EMAIL');
  if (typeof password !== 'string' || password.length < 6 || password.length > 72)
    return fail(res, 400, 'INVALID_PASSWORD');
  const hash = await bcrypt.hash(password, 10);
  try {
    const [r] = await pool.execute('INSERT INTO users (email, password_hash) VALUES (?, ?)', [email.toLowerCase(), hash]);
    log.info('user_registered', { user: r.insertId });
    res.status(201).json({ token: sign({ id: r.insertId, email, role: 'user' }), user: { email, role: 'user' } });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return fail(res, 409, 'EMAIL_EXISTS');
    throw e;
  }
}));

app.post('/api/auth/login', wrap(async (req, res) => {
  const { email, password } = req.body || {};
  if (typeof email !== 'string' || typeof password !== 'string') return fail(res, 400, 'INVALID_INPUT');
  const [rows] = await pool.execute('SELECT * FROM users WHERE email = ?', [email.toLowerCase()]);
  const u = rows[0];
  if (!u || !(await bcrypt.compare(password, u.password_hash))) {
    log.warn('login_failed', { ip: req.ip, email });
    return fail(res, 401, 'BAD_CREDENTIALS');
  }
  log.info('login_ok', { user: u.id, ip: req.ip });
  res.json({ token: sign(u), user: { email: u.email, role: u.role } });
}));

// ---------- Phim, suat chieu, ghe ----------
app.get('/api/movies', wrap(async (req, res) => {
  const [rows] = await pool.execute('SELECT id, title, duration, genre, description FROM movies ORDER BY id');
  res.json(rows);
}));

app.get('/api/movies/:id/showtimes', wrap(async (req, res) => {
  const [rows] = await pool.execute(
    `SELECT s.id, s.start_time, s.price, r.name AS room
       FROM showtimes s JOIN rooms r ON r.id = s.room_id
      WHERE s.movie_id = ? AND s.start_time > NOW() ORDER BY s.start_time`, [Number(req.params.id) || 0]);
  res.json(rows);
}));

app.get('/api/showtimes/:id/seats', wrap(async (req, res) => {
  const id = Number(req.params.id) || 0;
  const [st] = await pool.execute(
    `SELECT s.id, s.price, s.start_time, m.title, r.name AS room
       FROM showtimes s JOIN movies m ON m.id = s.movie_id JOIN rooms r ON r.id = s.room_id WHERE s.id = ?`, [id]);
  if (!st[0]) return fail(res, 404, 'NOT_FOUND');
  const [seats] = await pool.execute(
    `SELECT se.id, se.row_label, se.seat_no, se.type, b.status
       FROM showtimes st JOIN seats se ON se.room_id = st.room_id
       LEFT JOIN booking_seats bs ON bs.seat_id = se.id AND bs.showtime_id = st.id
       LEFT JOIN bookings b ON b.id = bs.booking_id
      WHERE st.id = ? ORDER BY se.row_label, se.seat_no`, [id]);
  res.json({
    showtime: st[0],
    seats: seats.map((s) => ({
      id: s.id, row: s.row_label, no: s.seat_no, type: s.type,
      state: s.status === 'paid' ? 'sold' : s.status === 'pending' ? 'held' : 'free',
    })),
  });
}));

// ---------- Dat ve (transaction + UNIQUE chong dat trung) ----------
app.post('/api/bookings', auth, wrap(async (req, res) => {
  const showtimeId = Number(req.body.showtimeId);
  const seatIds = Array.isArray(req.body.seatIds) ? [...new Set(req.body.seatIds.map(Number))] : [];
  if (!showtimeId || seatIds.length < 1 || seatIds.length > 8 || seatIds.some((n) => !Number.isInteger(n) || n < 1))
    return fail(res, 400, 'INVALID_INPUT');

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [st] = await conn.execute('SELECT room_id, price FROM showtimes WHERE id = ? AND start_time > NOW()', [showtimeId]);
    if (!st[0]) { await conn.rollback(); return fail(res, 404, 'SHOWTIME_NOT_AVAILABLE'); }
    const [seats] = await conn.query('SELECT id, type FROM seats WHERE room_id = ? AND id IN (?)', [st[0].room_id, seatIds]);
    if (seats.length !== seatIds.length) { await conn.rollback(); return fail(res, 400, 'INVALID_SEAT'); }
    const total = seats.reduce((sum, s) => sum + Number(st[0].price) * (s.type === 'vip' ? 1.5 : 1), 0);
    const [b] = await conn.execute(
      `INSERT INTO bookings (user_id, showtime_id, total, expires_at)
       VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 5 MINUTE))`, [req.user.id, showtimeId, total]);
    for (const seatId of seatIds)
      await conn.execute('INSERT INTO booking_seats (booking_id, showtime_id, seat_id) VALUES (?, ?, ?)', [b.insertId, showtimeId, seatId]);
    await conn.commit();
    bookingsTotal.inc({ status: 'created' });
    log.info('booking_created', { user: req.user.id, booking: b.insertId, showtime: showtimeId, seats: seatIds.length });
    const [row] = await pool.execute('SELECT id, total, status, expires_at FROM bookings WHERE id = ?', [b.insertId]);
    res.status(201).json(row[0]);
  } catch (e) {
    await conn.rollback();
    if (e.code === 'ER_DUP_ENTRY') {
      log.warn('SEAT_TAKEN', { user: req.user.id, showtime: showtimeId });
      return fail(res, 409, 'SEAT_TAKEN');
    }
    throw e;
  } finally { conn.release(); }
}));

async function releaseSeats(bookingId, newStatus) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    await conn.execute('DELETE FROM booking_seats WHERE booking_id = ?', [bookingId]);
    await conn.execute('UPDATE bookings SET status = ? WHERE id = ?', [newStatus, bookingId]);
    await conn.commit();
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
}

async function ownBooking(req, id) {
  const [rows] = await pool.execute('SELECT * FROM bookings WHERE id = ? AND user_id = ?', [id, req.user.id]);
  return rows[0];
}

// Thanh toan gia lap: ~90% thanh cong; body.simulate = 'success' | 'fail' de ep ket qua
app.post('/api/bookings/:id/pay', auth, wrap(async (req, res) => {
  const b = await ownBooking(req, Number(req.params.id) || 0);
  if (!b) return fail(res, 404, 'NOT_FOUND');
  if (b.status !== 'pending') return fail(res, 409, 'NOT_PENDING');
  if (new Date(b.expires_at) < new Date()) { await releaseSeats(b.id, 'cancelled'); bookingsTotal.inc({ status: 'expired' }); return fail(res, 410, 'EXPIRED'); }
  const sim = req.body && req.body.simulate;
  const ok = sim === 'success' ? true : sim === 'fail' ? false : Math.random() < 0.9;
  const txn = 'TXN' + Date.now().toString(36).toUpperCase();
  await pool.execute('INSERT INTO payments (booking_id, method, status, txn_code) VALUES (?, ?, ?, ?)',
    [b.id, 'fake_card', ok ? 'success' : 'failed', txn]);
  if (ok) {
    await pool.execute("UPDATE bookings SET status = 'paid' WHERE id = ?", [b.id]);
    bookingsTotal.inc({ status: 'paid' });
    log.info('payment_success', { user: req.user.id, booking: b.id, txn });
    return res.json({ status: 'paid', code: 'CB' + String(b.id).padStart(6, '0'), txn });
  }
  await releaseSeats(b.id, 'cancelled');
  bookingsTotal.inc({ status: 'failed' });
  log.error('payment_failed', { user: req.user.id, booking: b.id, txn });
  res.status(402).json({ error: 'PAYMENT_FAILED' });
}));

app.get('/api/bookings/me', auth, wrap(async (req, res) => {
  const [rows] = await pool.execute(
    `SELECT b.id, b.status, b.total, b.expires_at, b.created_at, m.title, s.start_time, r.name AS room,
            GROUP_CONCAT(CONCAT(se.row_label, se.seat_no) ORDER BY se.row_label, se.seat_no SEPARATOR ', ') AS seats
       FROM bookings b JOIN showtimes s ON s.id = b.showtime_id JOIN movies m ON m.id = s.movie_id
       JOIN rooms r ON r.id = s.room_id
       LEFT JOIN booking_seats bs ON bs.booking_id = b.id LEFT JOIN seats se ON se.id = bs.seat_id
      WHERE b.user_id = ? GROUP BY b.id, m.title, s.start_time, r.name ORDER BY b.id DESC LIMIT 50`, [req.user.id]);
  res.json(rows.map((r) => ({ ...r, code: 'CB' + String(r.id).padStart(6, '0') })));
}));

app.delete('/api/bookings/:id', auth, wrap(async (req, res) => {
  const b = await ownBooking(req, Number(req.params.id) || 0);
  if (!b) return fail(res, 404, 'NOT_FOUND');
  if (b.status === 'cancelled') return fail(res, 409, 'ALREADY_CANCELLED');
  if (b.status === 'paid') {
    const [st] = await pool.execute('SELECT start_time FROM showtimes WHERE id = ?', [b.showtime_id]);
    if (new Date(st[0].start_time) - Date.now() < 3600 * 1000) return fail(res, 409, 'TOO_LATE_TO_CANCEL');
  }
  await releaseSeats(b.id, 'cancelled');
  bookingsTotal.inc({ status: 'cancelled' });
  log.info('booking_cancelled', { user: req.user.id, booking: b.id });
  res.json({ status: 'cancelled' });
}));

// ---------- Admin ----------
app.get('/api/admin/stats', auth, adminOnly, wrap(async (req, res) => {
  const [rows] = await pool.execute(
    `SELECT COUNT(*) AS bookings, COALESCE(SUM(total), 0) AS revenue FROM bookings WHERE status = 'paid'`);
  res.json(rows[0]);
}));

// ---------- Static + loi ----------
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', (req, res) => fail(res, 404, 'NOT_FOUND'));
app.use((err, req, res, next) => {
  log.error('unhandled_error', { path: req.path, error: err.message });
  fail(res, 500, 'INTERNAL_ERROR');
});

// ---------- Khoi dong ----------
async function ensureUser(email, password, role) {
  const [rows] = await pool.execute('SELECT id FROM users WHERE email = ?', [email]);
  if (!rows[0]) {
    await pool.execute('INSERT INTO users (email, password_hash, role) VALUES (?, ?, ?)', [email, await bcrypt.hash(password, 10), role]);
    log.info('seed_user', { email, role });
  }
}

async function expireHolds() {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [rows] = await conn.query("SELECT id FROM bookings WHERE status = 'pending' AND expires_at < NOW() FOR UPDATE");
    if (rows.length) {
      const ids = rows.map((r) => r.id);
      await conn.query('DELETE FROM booking_seats WHERE booking_id IN (?)', [ids]);
      await conn.query("UPDATE bookings SET status = 'cancelled' WHERE id IN (?)", [ids]);
      bookingsTotal.inc({ status: 'expired' }, ids.length);
      log.info('holds_expired', { count: ids.length });
    }
    await conn.commit();
  } catch (e) { await conn.rollback(); log.error('expire_job_failed', { error: e.message }); } finally { conn.release(); }
}

(async () => {
  for (let i = 1; i <= 30; i++) {
    try { await pool.query('SELECT 1'); break; }
    catch (e) { log.warn('waiting_for_db', { attempt: i }); await new Promise((r) => setTimeout(r, 2000)); }
  }
  await ensureUser('admin@cinema.local', ADMIN_PASSWORD, 'admin');
  await ensureUser('user@cinema.local', DEMO_PASSWORD, 'user');
  setInterval(expireHolds, 30000);
  app.listen(PORT, () => log.info('server_started', { port: Number(PORT) }));
})();
