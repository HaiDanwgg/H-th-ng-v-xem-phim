const $ = (s) => document.querySelector(s);
const view = $('#view');
const state = {
  token: localStorage.getItem('token'),
  user: JSON.parse(localStorage.getItem('user') || 'null'),
  selected: new Set(), timer: null, registerMode: false,
};

const ERRORS = {
  SEAT_TAKEN: 'Ghế vừa có người khác đặt. Hãy chọn ghế khác.',
  BAD_CREDENTIALS: 'Email hoặc mật khẩu không đúng.',
  EMAIL_EXISTS: 'Email này đã có tài khoản. Hãy đăng nhập.',
  INVALID_EMAIL: 'Email không hợp lệ.',
  INVALID_PASSWORD: 'Mật khẩu cần từ 6 ký tự.',
  UNAUTHORIZED: 'Phiên đăng nhập hết hạn. Hãy đăng nhập lại.',
  PAYMENT_FAILED: 'Thanh toán thất bại. Ghế đã được trả lại, hãy chọn và thử lại.',
  EXPIRED: 'Đã quá 5 phút giữ ghế. Hãy chọn ghế lại.',
  TOO_LATE_TO_CANCEL: 'Chỉ hủy được vé trước giờ chiếu 1 tiếng.',
  NOT_PENDING: 'Đơn này không còn ở trạng thái chờ thanh toán.',
};
const errText = (e) => ERRORS[e.message] || 'Có lỗi xảy ra (' + e.message + '). Hãy thử lại.';

function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) el.setAttribute(k, v);
  }
  for (const c of kids.flat()) {
    if (c == null || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return el;
}
const money = (n) => Number(n).toLocaleString('vi-VN') + ' đ';
const when = (d) => new Date(d).toLocaleString('vi-VN', { weekday: 'short', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
const hues = [215, 340, 160, 28, 265, 190];
const poster = (m) => h('div', { class: 'poster', style: `background:linear-gradient(160deg,hsl(${hues[m.id % hues.length]} 55% 32%),hsl(${hues[(m.id + 2) % hues.length]} 60% 18%))` }, m.title);

function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 3500);
}

async function api(path, opts = {}) {
  const res = await fetch('/api' + path, {
    method: opts.method || 'GET',
    headers: { 'Content-Type': 'application/json', ...(state.token ? { Authorization: 'Bearer ' + state.token } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && state.token && !path.startsWith('/auth')) logout(true);
    throw Object.assign(new Error(data.error || 'ERROR'), { status: res.status });
  }
  return data;
}

// ---------- Auth ----------
function renderAuth() {
  const box = $('#auth'); box.replaceChildren();
  if (state.user) box.append(h('span', {}, state.user.email + ' '), h('button', { onclick: () => logout() }, 'Đăng xuất'));
  else box.append(h('button', { class: 'primary', onclick: () => openLogin() }, 'Đăng nhập'));
}
function openLogin(register = false) {
  state.registerMode = register;
  $('#login-title').textContent = register ? 'Đăng ký' : 'Đăng nhập';
  $('#login-submit').textContent = register ? 'Tạo tài khoản' : 'Đăng nhập';
  $('#login-switch').textContent = register ? 'Đã có tài khoản? Đăng nhập' : 'Chưa có tài khoản? Đăng ký';
  $('#login-error').textContent = '';
  $('#login').showModal();
}
function logout(expired) {
  state.token = null; state.user = null; localStorage.removeItem('token'); localStorage.removeItem('user');
  renderAuth(); if (expired) toast(ERRORS.UNAUTHORIZED); showMovies();
}
$('#login-close').onclick = () => $('#login').close();
$('#login-switch').onclick = () => openLogin(!state.registerMode);
$('#login-form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  try {
    const d = await api(state.registerMode ? '/auth/register' : '/auth/login', { method: 'POST', body: { email: $('#email').value, password: $('#password').value } });
    state.token = d.token; state.user = d.user;
    localStorage.setItem('token', d.token); localStorage.setItem('user', JSON.stringify(d.user));
    $('#login').close(); $('#password').value = ''; renderAuth(); toast('Xin chào ' + d.user.email);
  } catch (e) { $('#login-error').textContent = errText(e); }
});

// ---------- Man hinh ----------
async function showMovies() {
  clearInterval(state.timer);
  view.replaceChildren(h('h1', {}, 'Phim đang chiếu'), h('p', { class: 'sub' }, 'Chọn một phim để xem suất chiếu.'));
  try {
    const movies = await api('/movies');
    view.append(h('div', { class: 'grid' }, movies.map((m) =>
      h('button', { class: 'movie', onclick: () => showMovie(m) }, poster(m),
        h('div', { class: 'body' }, h('b', {}, m.title), h('div', { class: 'meta' }, m.genre + ' · ' + m.duration + ' phút'))))));
  } catch (e) { view.append(h('p', { class: 'empty' }, 'Không tải được danh sách phim. Hãy tải lại trang.')); }
}

async function showMovie(m) {
  view.replaceChildren(h('button', { class: 'link', onclick: showMovies }, '‹ Tất cả phim'), h('h1', {}, m.title),
    h('p', { class: 'sub' }, m.genre + ' · ' + m.duration + ' phút'), h('p', {}, m.description || ''), h('h2', {}, 'Suất chiếu'));
  try {
    const list = await api('/movies/' + m.id + '/showtimes');
    view.append(list.length ? h('div', { class: 'showtimes' }, list.map((s) =>
      h('button', { class: 'showtime', onclick: () => showSeats(s.id) }, h('b', {}, when(s.start_time)), s.room + ' · từ ' + money(s.price))))
      : h('p', { class: 'empty' }, 'Phim này chưa có suất chiếu sắp tới.'));
  } catch (e) { view.append(h('p', { class: 'empty' }, errText(e))); }
}

async function showSeats(id) {
  clearInterval(state.timer); state.selected = new Set();
  const { showtime: st, seats } = await api('/showtimes/' + id + '/seats').catch((e) => { toast(errText(e)); return {}; });
  if (!st) return;
  const price = Number(st.price);
  const rows = {}; seats.forEach((s) => (rows[s.row] = rows[s.row] || []).push(s));
  const summary = h('div', { class: 'panel' });
  const map = h('div', { class: 'seatmap' });

  const renderSummary = () => {
    const chosen = seats.filter((s) => state.selected.has(s.id));
    const total = chosen.reduce((a, s) => a + price * (s.type === 'vip' ? 1.5 : 1), 0);
    summary.replaceChildren(
      h('h2', {}, st.title),
      h('dl', {}, h('dt', {}, 'Suất chiếu'), h('dd', {}, when(st.start_time) + ' · ' + st.room),
        h('dt', {}, 'Ghế đã chọn'), h('dd', {}, chosen.length ? chosen.map((s) => s.row + s.no).join(', ') : 'Chưa chọn ghế')),
      h('div', { class: 'total' }, money(total)),
      h('button', { class: 'primary', disabled: chosen.length ? null : 'true', onclick: () => hold(id) }, 'Giữ ghế và thanh toán'),
      h('p', { class: 'sub' }, 'Ghế được giữ 5 phút. Ghế VIP giá ×1,5.'));
  };
  const renderMap = () => {
    map.replaceChildren(...Object.keys(rows).map((r) =>
      h('div', { class: 'seatrow' }, h('span', { class: 'rowlabel' }, r), rows[r].map((s) => {
        const sel = state.selected.has(s.id);
        const cls = ['seat', s.type === 'vip' ? 'vip' : '', s.no === 4 ? 'aisle' : '', s.state, sel ? 'selected' : ''].join(' ');
        return h('button', {
          class: cls, 'aria-label': 'Ghế ' + r + s.no + (s.type === 'vip' ? ' VIP' : '') + (s.state !== 'free' ? ', không chọn được' : ''),
          'aria-pressed': sel ? 'true' : 'false', disabled: s.state === 'free' ? null : 'true',
          onclick: () => { sel ? state.selected.delete(s.id) : state.selected.size < 8 && state.selected.add(s.id); renderMap(); renderSummary(); },
        }, s.no);
      }))));
  };
  renderMap(); renderSummary();
  view.replaceChildren(h('button', { class: 'link', onclick: showMovies }, '‹ Tất cả phim'), h('h1', {}, 'Chọn ghế'),
    h('div', { class: 'layout' }, h('div', {}, h('div', { class: 'screen' }), h('div', { class: 'screen-label' }, 'Màn hình'), map,
      h('div', { class: 'legend' }, h('span', {}, h('i'), 'Trống'), h('span', {}, h('i', { style: 'border-color:var(--vip)' }), 'VIP'),
        h('span', {}, h('i', { style: 'background:var(--held);border-color:var(--held)' }), 'Đang được giữ'),
        h('span', {}, h('i', { style: 'background:var(--sold);border-color:var(--sold)' }), 'Đã bán'))), summary));
}

async function hold(showtimeId) {
  if (!state.token) return openLogin();
  try {
    const b = await api('/bookings', { method: 'POST', body: { showtimeId, seatIds: [...state.selected] } });
    showCheckout(b);
  } catch (e) { toast(errText(e)); if (e.message === 'SEAT_TAKEN') showSeats(showtimeId); }
}

function showCheckout(b) {
  clearInterval(state.timer);
  const left = h('b', {});
  const tick = () => {
    const s = Math.max(0, Math.round((new Date(b.expires_at) - Date.now()) / 1000));
    left.textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
    if (s === 0) { clearInterval(state.timer); toast(ERRORS.EXPIRED); showMovies(); }
  };
  tick(); state.timer = setInterval(tick, 1000);
  const pay = async (simulate) => {
    try {
      const r = await api('/bookings/' + b.id + '/pay', { method: 'POST', body: simulate ? { simulate } : {} });
      clearInterval(state.timer);
      view.replaceChildren(h('h1', {}, 'Đặt vé thành công'), h('p', { class: 'sub' }, 'Đưa mã vé này cho nhân viên soát vé.'),
        h('div', { class: 'ticket' }, h('div', {}, h('div', { class: 'code' }, r.code), h('div', { class: 'meta' }, 'Mã giao dịch ' + r.txn)),
          h('button', { class: 'primary', onclick: showMyTickets }, 'Xem vé của tôi')));
    } catch (e) { toast(errText(e)); if (e.message !== 'ERROR') { clearInterval(state.timer); showMovies(); } }
  };
  view.replaceChildren(h('h1', {}, 'Thanh toán'), h('p', { class: 'sub' }, 'Thanh toán giả lập, không trừ tiền thật.'),
    h('div', { class: 'panel' }, h('dl', {}, h('dt', {}, 'Mã đơn'), h('dd', {}, '#' + b.id), h('dt', {}, 'Giữ ghế còn'), h('dd', {}, left)),
      h('div', { class: 'total' }, money(b.total)),
      h('div', { class: 'row' }, h('button', { class: 'primary', onclick: () => pay() }, 'Thanh toán'),
        h('button', { class: 'danger', onclick: () => pay('fail') }, 'Giả lập thanh toán lỗi'),
        h('button', { class: 'link', onclick: () => api('/bookings/' + b.id, { method: 'DELETE' }).then(showMovies) }, 'Hủy đơn'))));
}

async function showMyTickets() {
  clearInterval(state.timer);
  if (!state.token) { openLogin(); return; }
  view.replaceChildren(h('h1', {}, 'Vé của tôi'));
  try {
    const list = await api('/bookings/me');
    if (!list.length) return view.append(h('p', { class: 'empty' }, 'Bạn chưa đặt vé nào. Chọn một phim để bắt đầu.'));
    const label = { paid: 'Đã thanh toán', pending: 'Chờ thanh toán', cancelled: 'Đã hủy' };
    view.append(...list.map((t) => h('div', { class: 'ticket ' + t.status },
      h('div', {}, h('h2', {}, t.title), h('div', {}, when(t.start_time) + ' · ' + t.room), h('div', {}, 'Ghế: ' + (t.seats || '—')),
        h('div', { class: 'code' }, t.code)),
      h('div', {}, h('span', { class: 'badge' }, label[t.status]), h('div', { class: 'total' }, money(t.total)),
        t.status === 'paid' ? h('button', { class: 'danger', onclick: async () => { try { await api('/bookings/' + t.id, { method: 'DELETE' }); toast('Đã hủy vé'); showMyTickets(); } catch (e) { toast(errText(e)); } } }, 'Hủy vé') : null))));
  } catch (e) { view.append(h('p', { class: 'empty' }, errText(e))); }
}

$('#nav-movies').onclick = showMovies; $('#nav-tickets').onclick = showMyTickets;
$('#home').onclick = (e) => { e.preventDefault(); showMovies(); };
renderAuth(); showMovies();
