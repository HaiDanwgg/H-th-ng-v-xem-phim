#!/bin/bash
# Hardening co ban cho Ubuntu 22.04/24.04. Chay bang: sudo bash scripts/hardening.sh
# CANH BAO: hay chac chan da dang nhap duoc bang SSH key TRUOC khi tat dang nhap bang mat khau.
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Can chay bang root (sudo)"; exit 1; }

echo "[1/6] Cap nhat he thong + tu dong cap nhat bao mat"
apt-get update -y && apt-get upgrade -y
apt-get install -y ufw fail2ban unattended-upgrades auditd
dpkg-reconfigure -f noninteractive unattended-upgrades || true

echo "[2/6] Tuong lua UFW"
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

echo "[3/6] SSH"
cat > /etc/ssh/sshd_config.d/99-hardening.conf <<'CONF'
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
MaxAuthTries 3
X11Forwarding no
ClientAliveInterval 300
ClientAliveCountMax 2
CONF
sshd -t && systemctl reload ssh

echo "[4/6] fail2ban (SSH)"
cat > /etc/fail2ban/jail.d/cinema.local <<'CONF'
[sshd]
enabled = true
maxretry = 4
findtime = 10m
bantime = 1h
CONF
systemctl enable --now fail2ban && systemctl restart fail2ban

echo "[5/6] Tham so kernel (sysctl)"
cat > /etc/sysctl.d/99-hardening.conf <<'CONF'
net.ipv4.tcp_syncookies = 1
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.all.rp_filter = 1
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.conf.all.log_martians = 1
kernel.randomize_va_space = 2
CONF
sysctl --system >/dev/null

echo "[6/6] Kiem tra nhanh"
ufw status verbose
sshd -T | grep -Ei 'permitrootlogin|passwordauthentication'
echo "Xong. Docker tu mo cong bang iptables: chi publish 80/443 nhu trong docker-compose.yml."
