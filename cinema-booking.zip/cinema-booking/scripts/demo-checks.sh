#!/bin/bash
# Chay cac lenh kiem tra de chup anh / demo khi thi
echo "== Container =="; docker compose ps
echo "== Cong dang mo tren host =="; ss -tlnp | grep -E ':(80|443|9090|3306|3000)\b' || true
echo "== Header bao mat =="; curl -skI https://localhost/ | grep -Ei 'server|x-frame|x-content|content-security|referrer'
echo "== /metrics tu ngoai bi chan (mong doi 403) =="; curl -sk -o /dev/null -w '%{http_code}\n' https://localhost/metrics
echo "== Rate limit dang nhap (mong doi 401 ... roi 429) =="
for i in 1 2 3 4 5 6 7 8; do curl -sk -o /dev/null -w '%{http_code} ' -H 'Content-Type: application/json' -d '{"email":"x@x.com","password":"sai-mat-khau"}' https://localhost/api/auth/login; done; echo
echo "== Cau hinh Nginx hop le =="; docker compose exec nginx nginx -t
echo "== MySQL khong publish ra ngoai (khong thay 3306) =="; docker compose port db 3306 || echo "OK: khong publish"
echo "== UFW =="; sudo ufw status verbose 2>/dev/null || true
