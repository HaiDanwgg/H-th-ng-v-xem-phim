#!/bin/sh
# Tao chung chi TLS tu ky de test (chay 1 lan truoc khi docker compose up)
set -e
cd "$(dirname "$0")/certs"
openssl req -x509 -nodes -newkey rsa:2048 -days 365 \
  -keyout server.key -out server.crt \
  -subj "/CN=localhost" -addext "subjectAltName=DNS:localhost,IP:127.0.0.1"
chmod 600 server.key
echo "Da tao nginx/certs/server.crt va server.key"
