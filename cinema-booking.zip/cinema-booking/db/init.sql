USE cinema;
SET NAMES utf8mb4;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(100) NOT NULL,
  role ENUM('user','admin') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE movies (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  duration INT NOT NULL,
  genre VARCHAR(60),
  poster VARCHAR(255),
  description TEXT
) ENGINE=InnoDB;

CREATE TABLE rooms (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  total_seats INT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE seats (
  id INT AUTO_INCREMENT PRIMARY KEY,
  room_id INT NOT NULL,
  row_label CHAR(1) NOT NULL,
  seat_no INT NOT NULL,
  type ENUM('standard','vip') DEFAULT 'standard',
  UNIQUE KEY uq_seat (room_id, row_label, seat_no),
  FOREIGN KEY (room_id) REFERENCES rooms(id)
) ENGINE=InnoDB;

CREATE TABLE showtimes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  movie_id INT NOT NULL,
  room_id INT NOT NULL,
  start_time DATETIME NOT NULL,
  price DECIMAL(10,0) NOT NULL,
  INDEX idx_movie_time (movie_id, start_time),
  FOREIGN KEY (movie_id) REFERENCES movies(id),
  FOREIGN KEY (room_id) REFERENCES rooms(id)
) ENGINE=InnoDB;

CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  showtime_id INT NOT NULL,
  status ENUM('pending','paid','cancelled') DEFAULT 'pending',
  total DECIMAL(10,0) DEFAULT 0,
  expires_at DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user (user_id),
  INDEX idx_status_exp (status, expires_at),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (showtime_id) REFERENCES showtimes(id)
) ENGINE=InnoDB;

CREATE TABLE booking_seats (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  showtime_id INT NOT NULL,
  seat_id INT NOT NULL,
  UNIQUE KEY uq_showtime_seat (showtime_id, seat_id),
  FOREIGN KEY (booking_id) REFERENCES bookings(id),
  FOREIGN KEY (seat_id) REFERENCES seats(id)
) ENGINE=InnoDB;

CREATE TABLE payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  method VARCHAR(30),
  status ENUM('success','failed') NOT NULL,
  txn_code VARCHAR(40),
  paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id)
) ENGINE=InnoDB;

-- ---------- Du lieu mau ----------
INSERT INTO movies (title, duration, genre, description) VALUES
 ('Mưa Trên Phố Cũ', 118, 'Tình cảm', 'Hai người xa lạ cùng trú mưa trong một quán cà phê cũ giữa Hà Nội và bắt đầu câu chuyện kéo dài mười năm.'),
 ('Hành Tinh Cuối Cùng', 135, 'Khoa học viễn tưởng', 'Phi hành đoàn tìm kiếm ngôi nhà mới cho nhân loại và phát hiện mình không đơn độc.'),
 ('Đêm Không Ngủ', 102, 'Kinh dị', 'Một khách sạn ven biển, một đêm bão và những tiếng gõ cửa không ai giải thích được.'),
 ('Bếp Nhà Ba Tôi', 96, 'Gia đình', 'Cô con gái trở về quê học lại công thức nấu ăn của người cha sau nhiều năm xa cách.'),
 ('Truy Đuổi Lúc Nửa Đêm', 110, 'Hành động', 'Một tài xế giao hàng vô tình mang theo thứ mà cả thành phố đang săn lùng.');

INSERT INTO rooms (name, total_seats) VALUES ('Phòng 1', 48), ('Phòng 2 (VIP)', 48);

INSERT INTO seats (room_id, row_label, seat_no, type)
SELECT r.id, l.c, n.n, IF(l.c IN ('E','F'), 'vip', 'standard')
FROM rooms r
JOIN (SELECT 'A' c UNION SELECT 'B' UNION SELECT 'C' UNION SELECT 'D' UNION SELECT 'E' UNION SELECT 'F') l
JOIN (SELECT 1 n UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8) n;

INSERT INTO showtimes (movie_id, room_id, start_time, price)
SELECT m.id, IF(m.id % 2 = 0, 2, 1), DATE_ADD(DATE(NOW()), INTERVAL (d.d * 24 + h.h) HOUR), IF(h.h >= 18, 90000, 75000)
FROM movies m
JOIN (SELECT 0 d UNION SELECT 1 UNION SELECT 2 UNION SELECT 3) d
JOIN (SELECT 10 h UNION SELECT 14 UNION SELECT 19 UNION SELECT 21) h
WHERE (m.id + h.h + d.d) % 2 = 0;

-- ---------- Phan quyen (hardening) ----------
-- Tai khoan ung dung chi duoc DML tren DB cinema (ten cinema_app phai trung DB_USER trong .env)
REVOKE ALL PRIVILEGES ON cinema.* FROM 'cinema_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON cinema.* TO 'cinema_app'@'%';

-- Tai khoan chi doc cho mysqld-exporter (DOI MAT KHAU khi dung that, va sua monitoring/mysqld.cnf)
CREATE USER 'exporter'@'%' IDENTIFIED BY 'exporterpass' WITH MAX_USER_CONNECTIONS 3;
GRANT PROCESS, REPLICATION CLIENT, SELECT ON *.* TO 'exporter'@'%';
FLUSH PRIVILEGES;
